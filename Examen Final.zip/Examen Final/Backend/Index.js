import dotenv from "dotenv";
import express from "express";
import cors from "cors";
import pool from "./bd.js"; 

// rutas de las tabablas de la bd
import Ruta from "./Rutas/Ruta.js";
//import productosRouter from "./rutas/productos_rutas.js";
//import pedidosRouter from "./rutas/pedidos_rutas.js";
//import categoriasRouter from "./rutas/categorias_rutas.js";

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static('frontend'));

const port = process.env.PORT||3000;

app.get("/", (req, res) => {
  res.send("El servidor si jala");
});

// Endpoint para testear conexión a la BD
app.get("/test-db", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT 1 as test");
    res.json({ 
      success: true, 
      message: "Conexión a la base de datos exitosa",
      data: rows 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: "Error al conectar a la base de datos",
      error: error.message 
    });
  }
});

// coneccion de las rutas 
app.use("/usuarios", Ruta);
//app.use("/productos",productosRouter);
//app.use("/pedidos",pedidosRouter);
//app.use("/categorias",categoriasRouter);
 
app.listen(port, () => {
  console.log(`funcionando en el puerto ${port}`);
});