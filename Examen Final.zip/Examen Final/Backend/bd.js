import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config({ path: "./Backend/.env" });

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

// Prueba de conexión
pool.getConnection()
  .then(connection => {
    console.log("Base de datos conectada");
    connection.release();
  })
  .catch(err => {
    console.error(" Error al conectar a la base de datos:", err.message);
  });

export default pool;