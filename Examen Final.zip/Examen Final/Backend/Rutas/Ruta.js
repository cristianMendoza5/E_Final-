import { Router } from "express";
import pool from "../bd.js";

const router = Router();

 //GET Ruta para obtener los usuarios
router.get("/", async(req, res) => {
    try {
        const [rows] = await pool.query("SELECT * FROM usuarios"); // Cambia "usuarios" por el nombre de tu tabla
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

//POST Ruta para crear un usuario
router.post("/", async(req,res) => {
   const {id, nombre, email, password, rol, telefono} = req.body; // Cambia por los campos de tu tabla
    try {
         
         const [result] = await pool.query("INSERT INTO usuarios (id, nombre, email, password, rol, telefono) VALUES (?, ?, ?, ?, ?, ?)", [id, nombre, email, password, rol, telefono]); // Cambia "usuarios", los campos y las variables por los de tu tabla
         res.json(result);
   } catch (error) {
     res.status(500).json({ error: error.message });
   }   
})

//PUT Ruta para actualizar un usuario 
router.put('/:id', async (req, res) => {
  const { id } = req.params; // Cambia "id" por el nombre de tu campo primary key
  const { nombre, email, password, rol, telefono } = req.body; // Cambia por los campos de tu tabla (sin el ID)

  try {
    const [result] = await pool.query(
      'UPDATE usuarios SET nombre = ?, email = ?, password = ?, rol = ?, telefono = ? WHERE id = ?', // Cambia "usuarios", los campos SET y el campo WHERE por los de tu tabla
      [nombre, email, password, rol, telefono, id] // Cambia las variables por las de tu tabla (el ID siempre al final)
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Usuario no encontrado' }); // Cambia "Usuario" por el nombre de tu entidad
    }

    res.json({ message: 'Usuario actualizado correctamente' }); // Cambia "Usuario" por el nombre de tu entidad
  } catch (error) {
    console.error('Error al actualizar:', error);
    res.status(500).send('Error al actualizar usuario'); // Cambia "usuario" por el nombre de tu entidad
  }
});

//DELETE Ruta para eliminar un usuario
router.delete('/:id', async (req, res) => {
  const { id } = req.params; // Cambia "id" por el nombre de tu campo primary key

  try {
    const [result] = await pool.query('DELETE FROM usuarios WHERE id = ?', [id]); // Cambia "usuarios" por el nombre de tu tabla y "id" por tu primary key

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Usuario no encontrado' }); // Cambia "Usuario" por el nombre de tu entidad
    }

    res.json({ message: 'Usuario eliminado correctamente' }); // Cambia "Usuario" por el nombre de tu entidad
  } catch (error) {
    console.error('Error al eliminar:', error);
    res.status(500).send('Error al eliminar usuario'); // Cambia "usuario" por el nombre de tu entidad
  }
});

export default router;